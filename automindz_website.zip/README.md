# Automindz Website

A complete multi-page website for **Automindz** — an AI automation agency run by Raushan Dubey based in Patna, India.

## Tech Stack
- **HTML5**: Semantic structure
- **CSS3**: Custom variables, Grid/Flexbox, Animations
- **Vanilla JavaScript**: IntersectionObserver, Form handling, Custom interactivity

## Features
- **Dark Premium Theme**: AI-forward aesthetic with purple and cyan accents.
- **AI Voice Agent & Website Systems**: Detailed service sections.
- **Responsive Design**: Mobile-first approach.
- **Scroll Animations**: Smooth reveal effects as you scroll.
- **WhatsApp Integration**: Floating button and direct chat links.
- **Contact Form**: Integrated with Formspree (placeholder).

## Structure
- `index.html`: Home page
- `services.html`: Detailed solutions
- `how-it-works.html`: 3-step process & FAQ
- `results.html`: Case studies & stats
- `about.html`: Founder bio & expertise
- `contact.html`: Lead capture form

## Setup
Simply open `index.html` in any modern web browser. No build steps or dependencies required.
