import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Menu, X, ChevronDown, Phone, MessageCircle, Linkedin, Instagram, ArrowRight, Check, Zap, Users, TrendingUp, Clock, Target } from 'lucide-react';

const WHATSAPP_LINK = 'https://wa.me/917061409529';
const INSTAGRAM_LINK = 'https://instagram.com/raushandubay';
const LINKEDIN_LINK = 'https://linkedin.com/in/raushandubey';

// Animated Counter Component
function AnimatedCounter({ target, suffix = '' }: { target: number | string; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !hasAnimated.current) {
        hasAnimated.current = true;
        const targetNum = typeof target === 'string' ? parseInt(target) : target;
        const duration = 2000;
        const steps = 60;
        const increment = targetNum / steps;
        let current = 0;

        const timer = setInterval(() => {
          current += increment;
          if (current >= targetNum) {
            setCount(targetNum);
            clearInterval(timer);
          } else {
            setCount(Math.floor(current));
          }
        }, duration / steps);

        return () => clearInterval(timer);
      }
    });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [target]);

  return (
    <div ref={ref} className="text-3xl md:text-4xl font-bold">
      {count}{suffix}
    </div>
  );
}

// Scroll-triggered fade-in component
function FadeInOnScroll({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
      }
    }, { threshold: 0.1 });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} ${className}`}
    >
      {children}
    </div>
  );
}

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [displayText, setDisplayText] = useState('');
  const fullText = 'Aapka Business 24/7 Kaam Kare';

  // Typewriter effect
  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index <= fullText.length) {
        setDisplayText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 50);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <div className="w-full bg-background text-foreground">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-background/95 backdrop-blur border-b border-border' : 'bg-transparent'}`}>
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold bg-gradient-to-r from-accent to-blue-400 bg-clip-text text-transparent">
            Automindz
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('problems')} className="text-sm hover:text-accent transition-colors">Problems</button>
            <button onClick={() => scrollToSection('services')} className="text-sm hover:text-accent transition-colors">Services</button>
            <button onClick={() => scrollToSection('how-it-works')} className="text-sm hover:text-accent transition-colors">How It Works</button>
            <button onClick={() => scrollToSection('results')} className="text-sm hover:text-accent transition-colors">Results</button>
            <button onClick={() => scrollToSection('about')} className="text-sm hover:text-accent transition-colors">About</button>
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-background border-b border-border">
            <div className="container py-4 space-y-3">
              <button onClick={() => scrollToSection('problems')} className="block w-full text-left py-2 hover:text-accent transition-colors">Problems</button>
              <button onClick={() => scrollToSection('services')} className="block w-full text-left py-2 hover:text-accent transition-colors">Services</button>
              <button onClick={() => scrollToSection('how-it-works')} className="block w-full text-left py-2 hover:text-accent transition-colors">How It Works</button>
              <button onClick={() => scrollToSection('results')} className="block w-full text-left py-2 hover:text-accent transition-colors">Results</button>
              <button onClick={() => scrollToSection('about')} className="block w-full text-left py-2 hover:text-accent transition-colors">About</button>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="block">
                <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp
                </Button>
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-background to-purple-900/20" />
        <div className="absolute top-20 right-10 w-72 h-72 bg-accent/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

        <div className="container relative z-10 text-center max-w-4xl">
          <FadeInOnScroll>
            <div className="inline-block mb-6 px-4 py-2 bg-accent/10 border border-accent/30 rounded-full">
              <span className="text-sm text-accent font-medium">🚀 AI Automation for Your Business</span>
            </div>
          </FadeInOnScroll>

          <FadeInOnScroll className="mb-6">
            <h1 className="text-5xl md:text-7xl font-bold leading-tight">
              <span className="block">{displayText}<span className="animate-pulse">|</span></span>
              <span className="block bg-gradient-to-r from-accent via-blue-400 to-purple-400 bg-clip-text text-transparent">24/7 Kaam Kare</span>
              <span className="block">Aap Karo Ya Na Karo</span>
            </h1>
          </FadeInOnScroll>

          <FadeInOnScroll className="mb-8">
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              AI Voice Agents & Website Systems that never miss a call, capture every lead, and turn your business into a 24/7 revenue machine.
            </p>
          </FadeInOnScroll>

          <FadeInOnScroll className="mb-12">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground w-full sm:w-auto transition-all hover:scale-105">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  WhatsApp pe Baat Karo
                </Button>
              </a>
              <a href={`tel:+917061409529`}>
                <Button size="lg" variant="outline" className="border-accent text-accent hover:bg-accent/10 w-full sm:w-auto transition-all hover:scale-105">
                  <Phone className="w-5 h-5 mr-2" />
                  Book a Call
                </Button>
              </a>
            </div>
          </FadeInOnScroll>

          <FadeInOnScroll>
            <div className="flex flex-col sm:flex-row justify-center gap-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-accent" />
                <span>Free Consultation</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-accent" />
                <span>No Credit Card</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-accent" />
                <span>Quick Setup</span>
              </div>
            </div>
          </FadeInOnScroll>
        </div>
      </section>

      {/* Problem-Solution Section */}
      <section id="problems" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
              Kya Ye Aapke Saath Bhi Hota Hai?
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
              We understand the exact challenges you face. Here's how Automindz solves them.
            </p>
          </FadeInOnScroll>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Problems */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold mb-8">The Problem</h3>
              {[
                { icon: Phone, title: 'Missed Calls', desc: 'Lose leads while you\'re busy' },
                { icon: Users, title: 'No Follow-up System', desc: 'Leads go cold without proper nurturing' },
                { icon: TrendingUp, title: 'Bad Website', desc: 'Outdated or no online presence' },
                { icon: Clock, title: 'Manual Bookings', desc: 'Spend hours scheduling appointments' },
                { icon: Target, title: 'Lost Leads', desc: 'No system to track inquiries' },
              ].map((item, idx) => (
                <FadeInOnScroll key={idx}>
                  <div className="flex gap-4 p-4 rounded-lg bg-background/50 border border-border hover:border-accent/50 transition-colors">
                    <item.icon className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-semibold mb-1">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                </FadeInOnScroll>
              ))}
            </div>

            {/* Solutions */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold mb-8">Our Solution</h3>
              {[
                { icon: Zap, title: 'AI Voice Agent', desc: 'Answers calls 24/7, qualifies leads instantly' },
                { icon: TrendingUp, title: 'Auto Follow-up', desc: 'WhatsApp automation keeps leads warm' },
                { icon: Users, title: 'Professional Website', desc: 'Full business system with lead capture' },
                { icon: Clock, title: 'Instant Booking', desc: 'Automated scheduling, zero manual work' },
                { icon: Target, title: 'Lead Management', desc: 'CRM integration tracks every inquiry' },
              ].map((item, idx) => (
                <FadeInOnScroll key={idx}>
                  <div className="flex gap-4 p-4 rounded-lg bg-gradient-to-r from-accent/10 to-blue-500/10 border border-accent/30 hover:border-accent/60 transition-colors">
                    <item.icon className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-semibold mb-1">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                </FadeInOnScroll>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32">
        <div className="container">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
              Hamare Dono Services
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
              Two powerful solutions designed to transform your business
            </p>
          </FadeInOnScroll>

          <div className="grid md:grid-cols-2 gap-8">
            {/* AI Voice Agent */}
            <FadeInOnScroll>
              <Card className="bg-card border-border hover:border-accent/50 transition-all duration-300 overflow-hidden group h-full">
                <div className="h-1 bg-gradient-to-r from-accent to-blue-400 group-hover:h-2 transition-all" />
                <div className="p-8">
                  <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-6">
                    <Phone className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">AI Voice Agent</h3>
                  <p className="text-muted-foreground mb-6">
                    Intelligent voice AI that handles calls 24/7, qualifies leads, books appointments, and answers FAQs without any human intervention.
                  </p>

                  <ul className="space-y-3 mb-8">
                    {[
                      'Never miss a call again',
                      'Qualify leads automatically',
                      'Book appointments instantly',
                      'Save 20+ hours per week',
                    ].map((item, idx) => (
                      <li key={idx} className="flex items-center gap-3">
                        <Check className="w-5 h-5 text-accent flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>

                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                      Ye Chahiye Mujhe
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </a>
                </div>
              </Card>
            </FadeInOnScroll>

            {/* Website Systems */}
            <FadeInOnScroll>
              <Card className="bg-card border-border hover:border-accent/50 transition-all duration-300 overflow-hidden group h-full">
                <div className="h-1 bg-gradient-to-r from-blue-400 to-purple-400 group-hover:h-2 transition-all" />
                <div className="p-8">
                  <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-6">
                    <Users className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">Website Systems</h3>
                  <p className="text-muted-foreground mb-6">
                    Not just a website—a complete business system with lead capture, WhatsApp automation, booking flows, and CRM integration.
                  </p>

                  <ul className="space-y-3 mb-8">
                    {[
                      'Professional online presence',
                      'Lead capture & automation',
                      'WhatsApp integration',
                      'Google Maps & booking',
                    ].map((item, idx) => (
                      <li key={idx} className="flex items-center gap-3">
                        <Check className="w-5 h-5 text-accent flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>

                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                      Ye Chahiye Mujhe
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </a>
                </div>
              </Card>
            </FadeInOnScroll>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
              Kaise Kaam Karta Hai?
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
              A simple 3-step process to get your AI business system running
            </p>
          </FadeInOnScroll>

          <div className="grid md:grid-cols-3 gap-8 md:gap-4">
            {[
              { num: '01', title: 'Free Consultation', desc: '20-min call to understand your business needs and challenges' },
              { num: '02', title: 'Custom Plan', desc: 'We create a tailored solution scoped to your specific business' },
              { num: '03', title: 'Build & Launch', desc: 'Deploy your AI system in 7-14 days with full support' },
            ].map((step, idx) => (
              <FadeInOnScroll key={idx}>
                <div className="relative">
                  <div className="text-6xl font-bold text-accent/20 mb-4">{step.num}</div>
                  <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.desc}</p>
                  {idx < 2 && (
                    <div className="hidden md:block absolute top-8 -right-6 text-accent/30">
                      <ArrowRight className="w-8 h-8" />
                    </div>
                  )}
                </div>
              </FadeInOnScroll>
            ))}
          </div>

          <FadeInOnScroll className="text-center mt-16">
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Pehla Step Lo — Free Hai
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          </FadeInOnScroll>
        </div>
      </section>

      {/* Niche Clarity */}
      <section id="niches" className="py-20 md:py-32">
        <div className="container">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
              Automindz Exactly Kin Logo Ke Liye Hai?
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
              We specialize in two niches. Does one of these sound like you?
            </p>
          </FadeInOnScroll>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Interior Designers */}
            <FadeInOnScroll>
              <Card className="bg-gradient-to-br from-accent/10 to-blue-500/10 border-accent/30 hover:border-accent/60 transition-all">
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-6">Interior Designers</h3>
                  <ul className="space-y-4 mb-8">
                    {[
                      'Missing client calls while on-site visits',
                      'No proper lead follow-up system',
                      'Manually scheduling consultations',
                      'Spending too much time on admin',
                    ].map((item, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                      Haan, Ye Mera Liye Hai
                    </Button>
                  </a>
                </div>
              </Card>
            </FadeInOnScroll>

            {/* Plumbing Businesses */}
            <FadeInOnScroll>
              <Card className="bg-gradient-to-br from-accent/10 to-purple-500/10 border-accent/30 hover:border-accent/60 transition-all">
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-6">Plumbing Businesses</h3>
                  <ul className="space-y-4 mb-8">
                    {[
                      'Missing emergency calls = losing business',
                      'No 24/7 response system',
                      'Manual booking is chaotic',
                      'No way to follow up with past customers',
                    ].map((item, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                      Haan, Ye Mera Liye Hai
                    </Button>
                  </a>
                </div>
              </Card>
            </FadeInOnScroll>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section id="results" className="py-20 md:py-32 bg-card/50">
        <div className="container">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4">
              Ye Sirf Claims Nahi — Real Results Hain
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-center text-muted-foreground mb-4 max-w-2xl mx-auto">
              Results based on deployed client systems
            </p>
          </FadeInOnScroll>

          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {[
              { num: 24, suffix: '/7', label: 'AI Agent Always Active', icon: Zap },
              { num: 0, suffix: '', label: 'Missed Calls (with setup)', icon: Phone },
              { num: 48, suffix: 'h', label: 'Website Delivery', icon: Clock },
              { num: 3, suffix: 'x', label: 'Faster Lead Response', icon: TrendingUp },
            ].map((stat, idx) => (
              <FadeInOnScroll key={idx}>
                <Card className="bg-gradient-to-br from-accent/10 to-blue-500/10 border-accent/30 p-6 text-center hover:border-accent/60 transition-colors">
                  <stat.icon className="w-8 h-8 text-accent mx-auto mb-4" />
                  <AnimatedCounter target={stat.num} suffix={stat.suffix} />
                  <p className="text-sm text-muted-foreground mt-2">{stat.label}</p>
                </Card>
              </FadeInOnScroll>
            ))}
          </div>

          {/* Testimonials */}
          <div className="mt-20">
            <FadeInOnScroll>
              <h3 className="text-2xl font-bold text-center mb-12">What Our Clients Say</h3>
            </FadeInOnScroll>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: 'Priya Sharma',
                  business: 'Interior Designer',
                  quote: 'Automindz\'s AI agent has been a game-changer. I never miss a call anymore, and my consultations are booked automatically.',
                },
                {
                  name: 'Rajesh Kumar',
                  business: 'Plumbing Services',
                  quote: 'The 24/7 response system has increased my emergency bookings by 40%. This is exactly what my business needed.',
                },
                {
                  name: 'Neha Patel',
                  business: 'Design Studio',
                  quote: 'Setup was quick, and the WhatsApp automation keeps my leads engaged. Highly recommend Automindz!',
                },
              ].map((testimonial, idx) => (
                <FadeInOnScroll key={idx}>
                  <Card className="bg-card border-border p-6">
                    <div className="flex gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className="text-accent">★</span>
                      ))}
                    </div>
                    <p className="text-muted-foreground mb-4 italic">"{testimonial.quote}"</p>
                    <div>
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.business}</p>
                    </div>
                  </Card>
                </FadeInOnScroll>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About Founder */}
      <section id="about" className="py-20 md:py-32">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Founder Image Placeholder */}
            <FadeInOnScroll>
              <div className="flex justify-center">
                <div className="w-64 h-64 md:w-80 md:h-80 bg-gradient-to-br from-accent/20 to-blue-500/20 rounded-2xl border border-accent/30 flex items-center justify-center">
                  <div className="text-center">
                    <Users className="w-24 h-24 text-accent/50 mx-auto mb-4" />
                    <p className="text-muted-foreground">Raushan Dubey</p>
                    <p className="text-sm text-muted-foreground">Founder, Automindz</p>
                  </div>
                </div>
              </div>
            </FadeInOnScroll>

            {/* Founder Info */}
            <FadeInOnScroll>
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-6">
                  Automindz Ke Peeche Kaun Hai?
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  I'm Raushan Dubey, founder of Automindz. I built this agency because I saw small business owners in India struggling with the same problems: missed calls, no system, and wasted time on manual work.
                </p>
                <p className="text-lg text-muted-foreground mb-8">
                  My mission is simple: empower Indian entrepreneurs with AI automation so they can focus on what they do best—running their business—while AI handles the rest.
                </p>

                <div className="space-y-3 mb-8">
                  {[
                    'AI Automation Expert',
                    'Web Systems Designer',
                    'Voice Agent Developer',
                    'WhatsApp Bot Specialist',
                  ].map((skill, idx) => (
                    <div key={idx} className="flex items-center gap-3 px-4 py-2 bg-accent/10 border border-accent/30 rounded-lg w-fit">
                      <Zap className="w-4 h-4 text-accent" />
                      <span className="text-sm font-medium">{skill}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-4">
                  <a href={INSTAGRAM_LINK} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="border-accent text-accent hover:bg-accent/10">
                      <Instagram className="w-4 h-4 mr-2" />
                      Instagram
                    </Button>
                  </a>
                  <a href={LINKEDIN_LINK} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="border-accent text-accent hover:bg-accent/10">
                      <Linkedin className="w-4 h-4 mr-2" />
                      LinkedIn
                    </Button>
                  </a>
                </div>
              </div>
            </FadeInOnScroll>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="cta" className="py-20 md:py-32 bg-gradient-to-r from-accent/10 via-background to-blue-500/10 border-y border-accent/30">
        <div className="container text-center max-w-3xl mx-auto">
          <FadeInOnScroll>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Chalte Hain. Ek Free Call Mein Sab Clear Ho Jayega.
            </h2>
          </FadeInOnScroll>
          <FadeInOnScroll>
            <p className="text-lg text-muted-foreground mb-12">
              No pressure. No sales pitch. Just a genuine conversation about how Automindz can help your business grow.
            </p>
          </FadeInOnScroll>

          <FadeInOnScroll className="mb-12">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground w-full sm:w-auto">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  WhatsApp pe Baat Karo
                </Button>
              </a>
              <a href={`tel:+917061409529`}>
                <Button size="lg" variant="outline" className="border-accent text-accent hover:bg-accent/10 w-full sm:w-auto">
                  <Phone className="w-5 h-5 mr-2" />
                  Call: +91 70614 09529
                </Button>
              </a>
            </div>
          </FadeInOnScroll>

          <FadeInOnScroll>
            <div className="flex justify-center gap-6">
              <a href={INSTAGRAM_LINK} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
              <a href={LINKEDIN_LINK} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                <Linkedin className="w-6 h-6" />
              </a>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                <MessageCircle className="w-6 h-6" />
              </a>
            </div>
          </FadeInOnScroll>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="text-xl font-bold bg-gradient-to-r from-accent to-blue-400 bg-clip-text text-transparent mb-4">
                Automindz
              </div>
              <p className="text-sm text-muted-foreground">
                AI automation agency for Interior Designers & Plumbing businesses in India.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><button onClick={() => scrollToSection('services')} className="hover:text-accent transition-colors">Services</button></li>
                <li><button onClick={() => scrollToSection('how-it-works')} className="hover:text-accent transition-colors">How It Works</button></li>
                <li><button onClick={() => scrollToSection('about')} className="hover:text-accent transition-colors">About</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href={`tel:+917061409529`} className="hover:text-accent transition-colors">+91 70614 09529</a></li>
                <li><a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="hover:text-accent transition-colors">WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow</h4>
              <div className="flex gap-4">
                <a href={INSTAGRAM_LINK} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href={LINKEDIN_LINK} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Automindz. All rights reserved. | Built with AI for AI-powered businesses.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
