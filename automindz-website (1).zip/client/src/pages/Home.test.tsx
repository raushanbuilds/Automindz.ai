import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Home from './Home';

// Mock the router
vi.mock('wouter', () => ({
  Route: ({ component: Component }: any) => <Component />,
  Switch: ({ children }: any) => children,
}));

describe('Home Page', () => {
  it('renders the main navigation', () => {
    render(<Home />);
    expect(screen.getByText('Automindz')).toBeInTheDocument();
  });

  it('renders hero section with headline', () => {
    render(<Home />);
    expect(screen.getByText(/Aap Karo Ya Na Karo/)).toBeInTheDocument();
  });

  it('renders WhatsApp CTA button', () => {
    render(<Home />);
    const whatsappButtons = screen.getAllByText(/WhatsApp/);
    expect(whatsappButtons.length).toBeGreaterThan(0);
  });

  it('renders Book a Call button', () => {
    render(<Home />);
    expect(screen.getByText('Book a Call')).toBeInTheDocument();
  });

  it('renders all main sections', () => {
    render(<Home />);
    expect(screen.getByText(/Kya Ye Aapke Saath Bhi Hota Hai/)).toBeInTheDocument();
    expect(screen.getByText(/Hamare Dono Services/)).toBeInTheDocument();
    expect(screen.getByText(/Kaise Kaam Karta Hai/)).toBeInTheDocument();
    expect(screen.getByText(/Automindz Exactly Kin Logo Ke Liye Hai/)).toBeInTheDocument();
    expect(screen.getByText(/Ye Sirf Claims Nahi/)).toBeInTheDocument();
  });

  it('renders AI Voice Agent service', () => {
    render(<Home />);
    expect(screen.getByText('AI Voice Agent')).toBeInTheDocument();
  });

  it('renders Website Systems service', () => {
    render(<Home />);
    expect(screen.getByText('Website Systems')).toBeInTheDocument();
  });

  it('renders founder name in About section', () => {
    render(<Home />);
    expect(screen.getByText(/Raushan Dubey/)).toBeInTheDocument();
  });

  it('renders testimonials section', () => {
    render(<Home />);
    expect(screen.getByText(/What Our Clients Say/)).toBeInTheDocument();
    expect(screen.getByText('Priya Sharma')).toBeInTheDocument();
  });

  it('renders footer with copyright', () => {
    render(<Home />);
    expect(screen.getByText(/2026 Automindz/)).toBeInTheDocument();
  });

  it('renders mobile menu button', () => {
    render(<Home />);
    const menuButton = screen.getByRole('button', { name: '' });
    expect(menuButton).toBeInTheDocument();
  });

  it('opens mobile menu when menu button is clicked', async () => {
    const user = userEvent.setup();
    render(<Home />);
    
    // Find the menu button (it's the one without text in the mobile area)
    const buttons = screen.getAllByRole('button');
    const menuButton = buttons.find(btn => btn.querySelector('svg'));
    
    if (menuButton) {
      await user.click(menuButton);
      // Menu should now be visible
      await waitFor(() => {
        expect(screen.getByText('Problems')).toBeInTheDocument();
      });
    }
  });

  it('renders all navigation links', () => {
    render(<Home />);
    expect(screen.getAllByText('Problems').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Services').length).toBeGreaterThan(0);
    expect(screen.getAllByText('How It Works').length).toBeGreaterThan(0);
  });

  it('renders social media links', () => {
    render(<Home />);
    const instagramLinks = screen.getAllByRole('link').filter(link => 
      link.getAttribute('href')?.includes('instagram')
    );
    expect(instagramLinks.length).toBeGreaterThan(0);
  });

  it('renders problem-solution pairs', () => {
    render(<Home />);
    expect(screen.getByText('Missed Calls')).toBeInTheDocument();
    expect(screen.getByText('AI Voice Agent')).toBeInTheDocument();
  });

  it('renders niche cards for Interior Designers and Plumbing', () => {
    render(<Home />);
    expect(screen.getByText('Interior Designers')).toBeInTheDocument();
    expect(screen.getByText('Plumbing Businesses')).toBeInTheDocument();
  });

  it('renders results metrics section', () => {
    render(<Home />);
    expect(screen.getByText(/Ye Sirf Claims Nahi/)).toBeInTheDocument();
  });

  it('renders CTA section with proper heading', () => {
    render(<Home />);
    expect(screen.getByText(/Chalte Hain/)).toBeInTheDocument();
  });

  it('has proper link targets for external URLs', () => {
    render(<Home />);
    const whatsappLink = screen.getAllByRole('link').find(link =>
      link.getAttribute('href')?.includes('wa.me')
    );
    expect(whatsappLink).toHaveAttribute('target', '_blank');
  });
});
